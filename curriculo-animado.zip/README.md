# Currículo Animado

Este projeto é um site de currículo interativo e animado, desenvolvido com React. O objetivo é apresentar informações de forma dinâmica e atraente, utilizando animações de transição entre páginas e um fundo animado.

## Estrutura do Projeto

O projeto é organizado da seguinte forma:

- **public/index.html**: Página HTML principal que carrega o aplicativo React.
- **src/assets/background.jpg**: Imagem de fundo animado utilizada no site.
- **src/components/**: Contém os componentes reutilizáveis do site:
  - **Header.tsx**: Componente do cabeçalho com título e navegação.
  - **Footer.tsx**: Componente do rodapé com informações de contato.
  - **AnimatedBackground.tsx**: Componente que aplica a imagem de fundo animado.
  - **PageTransition.tsx**: Componente que gerencia as animações de transição entre páginas.
- **src/pages/**: Contém as páginas do currículo:
  - **Home.tsx**: Página inicial com visão geral das informações.
  - **Experiencia.tsx**: Seção de experiências profissionais.
  - **Formacao.tsx**: Seção de formação acadêmica.
  - **Contato.tsx**: Informações de contato e formulário.
- **src/App.tsx**: Componente principal que configura as rotas do aplicativo.
- **src/index.tsx**: Ponto de entrada do aplicativo React.
- **src/styles/global.css**: Estilos globais do site.
- **tsconfig.json**: Configuração do TypeScript.
- **package.json**: Configuração do npm com dependências e scripts.

## Instalação

Para instalar e executar o projeto, siga os passos abaixo:

1. Clone o repositório:
   ```
   git clone <URL_DO_REPOSITORIO>
   ```
2. Navegue até o diretório do projeto:
   ```
   cd curriculo-animado
   ```
3. Instale as dependências:
   ```
   npm install
   ```
4. Inicie o servidor de desenvolvimento:
   ```
   npm start
   ```

## Uso

Após iniciar o servidor, abra o navegador e acesse `http://localhost:3000` para visualizar o currículo animado. Navegue entre as páginas para explorar as diferentes seções do currículo.

## Contribuição

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou pull requests para melhorias e correções.