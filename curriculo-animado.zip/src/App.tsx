import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import AnimatedBackground from './components/AnimatedBackground';
import PageTransition from './components/PageTransition';
import Home from './pages/Home';
import Experiencia from './pages/Experiencia';
import Formacao from './pages/Formacao';
import Contato from './pages/Contato';
import './styles/global.css';

const App = () => {
  return (
    <Router>
      <AnimatedBackground>
        <Header />
        <PageTransition>
          <Switch>
            <Route path="/" exact component={Home} />
            <Route path="/experiencia" component={Experiencia} />
            <Route path="/formacao" component={Formacao} />
            <Route path="/contato" component={Contato} />
          </Switch>
        </PageTransition>
        <Footer />
      </AnimatedBackground>
    </Router>
  );
};

export default App;