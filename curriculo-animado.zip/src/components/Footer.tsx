import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer">
            <p>&copy; {new Date().getFullYear()} Seu Nome. Todos os direitos reservados.</p>
            <p>Contato: seuemail@example.com</p>
        </footer>
    );
};

export default Footer;