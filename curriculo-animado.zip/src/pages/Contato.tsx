import React from 'react';

const Contato: React.FC = () => {
    return (
        <div className="contato">
            <h1>Contato</h1>
            <p>Se você deseja entrar em contato, preencha o formulário abaixo:</p>
            <form>
                <div>
                    <label htmlFor="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" required />
                </div>
                <div>
                    <label htmlFor="email">Email:</label>
                    <input type="email" id="email" name="email" required />
                </div>
                <div>
                    <label htmlFor="mensagem">Mensagem:</label>
                    <textarea id="mensagem" name="mensagem" required></textarea>
                </div>
                <button type="submit">Enviar</button>
            </form>
        </div>
    );
};

export default Contato;