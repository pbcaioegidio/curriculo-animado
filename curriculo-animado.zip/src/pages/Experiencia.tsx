import React from 'react';

const Experiencia: React.FC = () => {
    return (
        <div className="experiencia">
            <h1>Experiência Profissional</h1>
            <ul>
                <li>
                    <h2>Nome da Empresa 1</h2>
                    <p>Cargo: Desenvolvedor Frontend</p>
                    <p>Duração: Janeiro 2020 - Presente</p>
                    <p>Descrição: Desenvolvimento de aplicações web utilizando React e TypeScript.</p>
                </li>
                <li>
                    <h2>Nome da Empresa 2</h2>
                    <p>Cargo: Estagiário em Desenvolvimento</p>
                    <p>Duração: Junho 2019 - Dezembro 2019</p>
                    <p>Descrição: Auxílio no desenvolvimento de projetos e manutenção de sistemas existentes.</p>
                </li>
                {/* Adicione mais experiências conforme necessário */}
            </ul>
        </div>
    );
};

export default Experiencia;