import React from 'react';

const Formacao: React.FC = () => {
    return (
        <div className="formacao">
            <h1>Formação Acadêmica</h1>
            <ul>
                <li>
                    <h2>Nome da Instituição</h2>
                    <p>Curso: Nome do Curso</p>
                    <p>Ano de Conclusão: 2023</p>
                </li>
                <li>
                    <h2>Nome da Instituição</h2>
                    <p>Curso: Nome do Curso</p>
                    <p>Ano de Conclusão: 2021</p>
                </li>
                {/* Adicione mais itens de formação conforme necessário */}
            </ul>
        </div>
    );
};

export default Formacao;