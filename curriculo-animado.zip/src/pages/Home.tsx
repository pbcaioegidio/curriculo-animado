import React from 'react';
import AnimatedBackground from '../components/AnimatedBackground';
import Header from '../components/Header';
import Footer from '../components/Footer';
import PageTransition from '../components/PageTransition';

const Home: React.FC = () => {
    return (
        <AnimatedBackground>
            <PageTransition>
                <Header />
                <div className="home-content">
                    <h1>Bem-vindo ao meu Currículo</h1>
                    <p>Aqui você encontrará informações sobre minha formação, experiências e como entrar em contato.</p>
                </div>
                <Footer />
            </PageTransition>
        </AnimatedBackground>
    );
};

export default Home;